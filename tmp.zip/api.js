// Minimal SCORM 1.2 runtime shim (MVP)
window.SCORM_API = {
  setStatus: function (status) { try { console.log('SCORM status:', status); } catch (e) {} }
};